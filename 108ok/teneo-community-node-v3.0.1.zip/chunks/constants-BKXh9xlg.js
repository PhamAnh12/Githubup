const o="https://dashboard.teneo.pro";export{o as w};
